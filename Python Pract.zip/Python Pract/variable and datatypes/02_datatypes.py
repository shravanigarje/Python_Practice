a=1   #a is integer
b=5.22    #floating
c="soham"  #string
d= False   # boolean
e= None    #none type variable