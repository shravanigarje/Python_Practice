# a= input("enter num 1:")
# b= input("enter num 2:")
# print("Number a is:",a)          #1
# print("Number b is:",b)          #2
# print(a+b)                       #12    because its string
 
 #For Adding
a=int( input("enter num 1:"))
b= int(input("enter num 2:"))
print("Number a is:",a)          #1
print("Number b is:",b)          #2
print(a+b)                       #12    because its string
 