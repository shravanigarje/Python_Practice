a=31.2
t=type(a)
print(t)


a="shravani"
t=type(a)
print(t)


#conversions
str(31)
int("12")
float(32)
print(str, int,float)