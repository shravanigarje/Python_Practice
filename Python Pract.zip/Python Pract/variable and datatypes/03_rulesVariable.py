a=52
aaa=54
b=12
harry=34
_sammerr=23
@sameer=56      #not allowed       


# vari starts with alphabet and underscore
# cant start with number
# neither special character
# no space