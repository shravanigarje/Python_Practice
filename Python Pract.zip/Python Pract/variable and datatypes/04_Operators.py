#arithmetic

a=34
b=4
print(a-b)

a=34
b=4
c=a+b
print(c)

# Assignment oper
a=4-2
print(a)
b=6
b+=3  #increment val of b by 3
print(b)


#Comaprison
a=5
b=2 
print(b>a)    #boolean value
  

#Logical
a= True or False                  
print(a)
