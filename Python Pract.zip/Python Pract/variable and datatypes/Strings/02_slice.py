name="HArry" 
print(len(name))

nameshort=name[0:3]  #start from index 0 to 2
print(nameshort)

#negative slice
print(name[-4:-1])                              
print(name[1:4])  #convert negavtive to positive by corresponding
print(name[:4])  #same as print(name[0:4])  0 index
print(name[1:])  #same as print(name[1:5])   5 is length
print(name[1:5])
print(name[:])  

word="amazing"
print(word[1:6:2])