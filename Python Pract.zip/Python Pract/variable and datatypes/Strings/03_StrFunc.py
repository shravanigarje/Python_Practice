name="Harry"
print(len(name))
print(name.endswith("rry"))
print(name.startswith("H"))
print(name.capitalize())

a="Shravani is nice"
print(a.replace("nice","kind"))
