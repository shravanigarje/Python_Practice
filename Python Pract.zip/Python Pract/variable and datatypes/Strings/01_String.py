print("Shravani")
print('Shravani')
print('''Shravani
      Garje''')