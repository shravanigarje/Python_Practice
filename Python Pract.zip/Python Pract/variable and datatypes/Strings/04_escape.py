a="Shravani is good girl\nbut not a bad girl"
print(a)       #\n new line

a="Shravani is bad \t good"