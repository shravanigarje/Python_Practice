#to find avg of two num entered by user
a=int(input("Enter value of a:"))
b=int(input("Enter value of b:"))


print("The avg of two number is",(a+b)/2)