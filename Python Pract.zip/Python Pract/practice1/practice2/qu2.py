#to find reminder when num divided 
 
a=34
b=5
print(a%b)