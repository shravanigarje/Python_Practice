#use comparison oper to find out whether a given vari a is greater than b  or not
 

a=34
b=80
print(a>b)

#using input
a=int(input("Enter value of a:"))
b=int(input("Enter value of b:"))
print(a>b)