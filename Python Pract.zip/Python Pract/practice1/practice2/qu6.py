#calculate square of a num

a=int(input("Enter value of a:"))
print("The avg of two number is",a**2)

