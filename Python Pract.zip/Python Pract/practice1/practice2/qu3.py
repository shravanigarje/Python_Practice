#check type of variable using input()
a=float(input("Enter value of a:"))
print(type(a))